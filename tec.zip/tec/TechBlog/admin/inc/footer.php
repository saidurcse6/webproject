<div class="clear">
        </div>
    </div>
    <div class="clear">
    </div>
    <div id="site_info">
        <p>
         &copy; All news about bd cricket. All Rights Reserved.
        </p>
    </div>
</body>
</html>
